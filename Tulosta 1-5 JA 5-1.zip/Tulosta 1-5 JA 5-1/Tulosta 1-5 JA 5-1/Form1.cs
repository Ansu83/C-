namespace Tulosta_1_5_JA_5_1
{
    public partial class frmTulosta15JA51 : Form
    {
        public frmTulosta15JA51()
        {
            InitializeComponent();
        }

        private void btnTulosta_Click(object sender, EventArgs e)
        {
            string T15 = "";
            string T51 = "";
            int i = 0;

            while (i < 5)
            {
                T15 = T15 + Convert.ToString(i + 1) + Environment.NewLine;
                i++;
         
            }

            while (i > 0) 
            {
                T51 = T51 + Convert.ToString(i) + Environment.NewLine;
                i--;
            }

            txtT15.Text = T15.ToString();
            txtT51.Text = T51.ToString();

            int Aloitusluku, Lopetusluku;
            Aloitusluku = int.Parse(txtAloitusluku.Text);
            Lopetusluku = int.Parse(txtLopetusluku.Text);
            string LukujenVali = "";
            i = Aloitusluku;

            while (i <= Lopetusluku)
            {
                LukujenVali = LukujenVali + Convert.ToString(i) + Environment.NewLine;  
                i++;
            }

            txtLukujenVali.Text = LukujenVali.ToString();
        }

        private void txtLopetusluku_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblLukujenVali_Click(object sender, EventArgs e)
        {

        }
    }
}
