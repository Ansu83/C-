﻿namespace Tulosta_1_5_JA_5_1
{
    partial class frmTulosta15JA51
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblT15 = new Label();
            lblT51 = new Label();
            txtT15 = new TextBox();
            txtT51 = new TextBox();
            btnTulosta = new Button();
            lblAloitusluku = new Label();
            lblLopetusluku = new Label();
            txtAloitusluku = new TextBox();
            txtLopetusluku = new TextBox();
            txtLukujenVali = new TextBox();
            lblLukujenVali = new Label();
            SuspendLayout();
            // 
            // lblT15
            // 
            lblT15.AutoSize = true;
            lblT15.Location = new Point(25, 18);
            lblT15.Name = "lblT15";
            lblT15.Size = new Size(24, 15);
            lblT15.TabIndex = 0;
            lblT15.Text = "1-5";
            // 
            // lblT51
            // 
            lblT51.AutoSize = true;
            lblT51.Location = new Point(25, 113);
            lblT51.Name = "lblT51";
            lblT51.Size = new Size(24, 15);
            lblT51.TabIndex = 1;
            lblT51.Text = "5-1";
            // 
            // txtT15
            // 
            txtT15.Location = new Point(103, 18);
            txtT15.Multiline = true;
            txtT15.Name = "txtT15";
            txtT15.Size = new Size(46, 89);
            txtT15.TabIndex = 2;
            // 
            // txtT51
            // 
            txtT51.Location = new Point(103, 113);
            txtT51.Multiline = true;
            txtT51.Name = "txtT51";
            txtT51.Size = new Size(46, 86);
            txtT51.TabIndex = 3;
            // 
            // btnTulosta
            // 
            btnTulosta.Location = new Point(17, 391);
            btnTulosta.Name = "btnTulosta";
            btnTulosta.Size = new Size(75, 23);
            btnTulosta.TabIndex = 4;
            btnTulosta.Text = "Tulosta";
            btnTulosta.UseVisualStyleBackColor = true;
            btnTulosta.Click += btnTulosta_Click;
            // 
            // lblAloitusluku
            // 
            lblAloitusluku.AutoSize = true;
            lblAloitusluku.Location = new Point(25, 219);
            lblAloitusluku.Name = "lblAloitusluku";
            lblAloitusluku.Size = new Size(67, 15);
            lblAloitusluku.TabIndex = 5;
            lblAloitusluku.Text = "Aloitusluku";
            // 
            // lblLopetusluku
            // 
            lblLopetusluku.AutoSize = true;
            lblLopetusluku.Location = new Point(22, 248);
            lblLopetusluku.Name = "lblLopetusluku";
            lblLopetusluku.Size = new Size(72, 15);
            lblLopetusluku.TabIndex = 6;
            lblLopetusluku.Text = "Lopetusluku";
            // 
            // txtAloitusluku
            // 
            txtAloitusluku.Location = new Point(103, 216);
            txtAloitusluku.Name = "txtAloitusluku";
            txtAloitusluku.Size = new Size(46, 23);
            txtAloitusluku.TabIndex = 7;
            // 
            // txtLopetusluku
            // 
            txtLopetusluku.Location = new Point(103, 245);
            txtLopetusluku.Name = "txtLopetusluku";
            txtLopetusluku.Size = new Size(46, 23);
            txtLopetusluku.TabIndex = 8;
            txtLopetusluku.TextChanged += txtLopetusluku_TextChanged;
            // 
            // txtLukujenVali
            // 
            txtLukujenVali.Location = new Point(103, 278);
            txtLukujenVali.Multiline = true;
            txtLukujenVali.Name = "txtLukujenVali";
            txtLukujenVali.Size = new Size(46, 136);
            txtLukujenVali.TabIndex = 9;
            // 
            // lblLukujenVali
            // 
            lblLukujenVali.AutoSize = true;
            lblLukujenVali.Location = new Point(22, 278);
            lblLukujenVali.Name = "lblLukujenVali";
            lblLukujenVali.Size = new Size(70, 15);
            lblLukujenVali.TabIndex = 10;
            lblLukujenVali.Text = "Lukujen väli";
            lblLukujenVali.Click += lblLukujenVali_Click;
            // 
            // frmTulosta15JA51
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblLukujenVali);
            Controls.Add(txtLukujenVali);
            Controls.Add(txtLopetusluku);
            Controls.Add(txtAloitusluku);
            Controls.Add(lblLopetusluku);
            Controls.Add(lblAloitusluku);
            Controls.Add(btnTulosta);
            Controls.Add(txtT51);
            Controls.Add(txtT15);
            Controls.Add(lblT51);
            Controls.Add(lblT15);
            Name = "frmTulosta15JA51";
            Text = "Tulosta 1...5 JA 5...1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblT15;
        private Label lblT51;
        private TextBox txtT15;
        private TextBox txtT51;
        private Button btnTulosta;
        private Label lblAloitusluku;
        private Label lblLopetusluku;
        private TextBox txtAloitusluku;
        private TextBox txtLopetusluku;
        private TextBox txtLukujenVali;
        private Label lblLukujenVali;
    }
}
